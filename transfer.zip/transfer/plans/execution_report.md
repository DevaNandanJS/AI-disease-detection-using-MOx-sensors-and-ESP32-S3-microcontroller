# XGBoost Model Training: Execution Report

This report outlines the complete workflow for training, evaluating, and interpreting an XGBoost model using your preprocessed data. Each step includes the necessary theory, code, and explanations to guide you.

### Proposed File Structure

To keep your project organized, all the following code should be placed in a **new file** named `train_model.py`. This separates the model training logic from your EDA and preprocessing scripts.

Your project directory will look like this:

```
C:\ESP-32 ML Test
├───EDA.py
├───preprocessing.py
├───train_model.py  <-- You will create this file
├───dataset_preprocessed
└───... (other files)
```

---

## Step 1: Setup and Loading Preprocessed Data

**Objective:**
Prepare your script by importing necessary libraries and loading the cleaned data you created in `preprocessing.py`.

**Theory:**
We start by importing all the tools we'll need: pandas for data manipulation, XGBoost for the model, and scikit-learn for splitting the data and evaluating performance. We must load the `dataset_preprocessed` file because it contains the clean, encoded data ready for the model. From this, we will separate our data into the feature matrix `X` (the inputs) and the target vector `y` (what we want to predict).

**Code for `train_model.py`:**

```python
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt

# --- 1. Load and Prepare Data ---
try:
    # Load the preprocessed dataset
    df = pd.read_csv('dataset_preprocessed')
    print("Preprocessed dataset loaded successfully.")
except FileNotFoundError:
    print("Error: 'dataset_preprocessed' not found.")
    print("Please run preprocessing.py first to generate the file.")
    exit() # Exit the script if the file doesn't exist

# Separate features (X) and target (y)
X = df.drop('Target', axis=1)
y = df['Target']

print(f"Feature matrix shape: {X.shape}")
print(f"Target vector shape: {y.shape}")
```

---

## Step 2: Address Class Imbalance with `scale_pos_weight`

**Objective:**
Calculate a weight to penalize the model more for misclassifying the minority class. This is the most important step for handling imbalanced data with XGBoost.

**Theory:**
Your dataset is likely imbalanced (one class has far more samples than the other). A "naive" model could achieve high accuracy by simply always predicting the majority class, but it would be useless. We need to force the model to learn the patterns of the minority class.

The `scale_pos_weight` parameter in XGBoost does exactly this. It increases the cost (loss) associated with making a mistake on a minority class sample. A standard way to calculate it is:

`scale_pos_weight = count(majority_class) / count(minority_class)`

Let's assume your label encoder mapped the minority class to `1` and the majority to `0`. The formula would be `count(class_0) / count(class_1)`.

**Code for `train_model.py` (continued):**

```python
# --- 2. Handle Class Imbalance ---
# Calculate scale_pos_weight
# First, count the occurrences of each class
class_counts = y.value_counts()
print("
Class distribution:")
print(class_counts)

# Assuming class '0' is the majority and '1' is the minority
# If your encoding is different, you may need to swap these
scale_pos_weight = class_counts[0] / class_counts[1]
print(f"Calculated scale_pos_weight: {scale_pos_weight:.2f}")

```

---

## Step 3: Splitting Data into Training and Testing Sets

**Objective:**
Divide your data into two sets: one for training the model and a separate one for evaluating its performance on unseen data.

**Theory:**
This is the golden rule of machine learning: **never test your model on the same data it was trained on.** The `train_test_split` function from scikit-learn handles this. We will give the model the training set (`X_train`, `y_train`) to learn from. Then, we'll use the testing set (`X_test`, `y_test`) to see how well it generalizes to new, unseen examples.

*   `test_size=0.2`: This reserves 20% of the data for testing and uses the other 80% for training.
*   `stratify=y`: This is **critical** for imbalanced datasets. It ensures that the proportion of majority/minority classes in both the training and testing sets is the same as in the original dataset.
*   `random_state=42`: This ensures that the split is the same every time you run the code, making your results reproducible.

**Code for `train_model.py` (continued):**

```python
# --- 3. Split Data ---
# Split the data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y, # Essential for imbalanced datasets
    random_state=42
)

print("
Data split into training and testing sets:")
print(f"X_train shape: {X_train.shape}")
print(f"X_test shape: {X_test.shape}")
```

---

## Step 4: Training the XGBoost Classifier

**Objective:**
Instantiate and train the XGBoost model using our prepared training data and imbalance-handling parameter.

**Theory:**
XGBoost (eXtreme Gradient Boosting) is an ensemble learning method. It builds a series of decision trees sequentially, where each new tree tries to correct the errors made by the previous ones. `XGBClassifier` is the specific class for classification problems.

When we create the model, we pass in our `scale_pos_weight`. We also use other important parameters:
*   `use_label_encoder=False`: Suppresses a deprecation warning.
*   `eval_metric='logloss'`: Specifies the metric to use for evaluation during training.
*   `random_state=42`: Ensures the model's internal randomness is the same each time, for reproducibility.

The `model.fit(X_train, y_train)` command starts the training process. The model will iterate through the training data and build the decision trees.

**Code for `train_model.py` (continued):**

```python
# --- 4. Train the XGBoost Model ---
print("
Training XGBoost model...")

# Instantiate the XGBoost classifier with our parameters
model = xgb.XGBClassifier(
    scale_pos_weight=scale_pos_weight,
    use_label_encoder=False,
    eval_metric='logloss',
    random_state=42
)

# Train the model on the training data
model.fit(X_train, y_train)

print("Model training complete.")
```

---

## Step 5: Evaluating Model Performance

**Objective:**
Use the held-out test set to evaluate how well our model performs, using appropriate metrics for imbalanced data.

**Theory:**
Now that the model is trained, we use `model.predict(X_test)` to get its predictions on the unseen test data. We then compare these predictions (`y_pred`) to the true labels (`y_test`).

*   **Confusion Matrix**: A table that shows the model's performance. It breaks down predictions into True Positives, True Negatives, False Positives, and False Negatives. This helps you see exactly where the model is getting confused.
*   **Classification Report**: Provides key metrics:
    *   **Precision**: Of all the times the model predicted a class, how often was it correct? (`TP / (TP + FP)`)
    *   **Recall (Sensitivity)**: Of all the actual instances of a class, how many did the model correctly identify? (`TP / (TP + FN)`) This is often the most important metric for a minority class.
    *   **F1-Score**: The harmonic mean of Precision and Recall, providing a single score that balances both.

**Code for `train_model.py` (continued):**

```python
# --- 5. Evaluate the Model ---
print("
Evaluating model performance on the test set...")

# Make predictions on the test data
y_pred = model.predict(X_test)

# Print the classification report
print("
Classification Report:")
print(classification_report(y_test, y_pred))

# Print the confusion matrix
print("
Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
```

---

## Step 6: Analyzing Feature Importance

**Objective:**
Understand which of the original features the model found most useful for making its predictions.

**Theory:**
A great advantage of tree-based models like XGBoost is their interpretability. The model automatically calculates an "importance" score for each feature based on how much that feature contributed to improving the model's performance across all the decision trees. This can give you valuable insights into the underlying data.

**Code for `train_model.py` (continued):**

```python
# --- 6. Analyze Feature Importance ---
print("
Plotting feature importance...")

fig, ax = plt.subplots(figsize=(10, 8))
xgb.plot_importance(model, ax=ax, max_num_features=15) # Plot top 15 features
plt.title("XGBoost Feature Importance")
plt.tight_layout()
plt.show()

print("
Execution complete.")

```
This final script provides a complete, robust, and reproducible workflow for your modeling task.
