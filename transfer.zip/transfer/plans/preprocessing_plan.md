# Data Preprocessing Plan

This report provides a detailed, step-by-step guide for preprocessing the `MOX-DISEASE_MERGED.csv` dataset. The goal is to clean and transform the data into a format suitable for training an XGBoost model. This plan is based on the findings from the initial Exploratory Data Analysis (EDA).

---

### **Step 1: Drop Columns with High Percentage of Missing Values**

**Objective:**
Remove features that are almost entirely empty and provide no useful information for the model.

**Theory:**
Your EDA revealed that several columns have over 90% of their values missing (e.g., `SP-3`, `TGS-822`, `TGS-2600`, etc.). It is not feasible to accurately impute (fill in) this much missing data. Attempting to do so would introduce significant noise and potentially misleading patterns. The best practice is to remove these columns entirely, as they lack sufficient data to contribute to a predictive model.

**Tools & Syntax:**

*   We will first define a threshold (e.g., 90%) for missing data.
*   Then, we'll calculate the percentage of missing values for each column.
*   Finally, we'll drop any column that exceeds this threshold using the pandas `.drop()` method.

```python
# Assuming 'dataset' is your loaded DataFrame
# --- Add this code to your script after loading the data ---

# Define the threshold for dropping columns
threshold = 0.90  # 90%

# Identify columns to drop
missing_percentage = dataset.isnull().sum() / len(dataset)
cols_to_drop = missing_percentage[missing_percentage > threshold].keys()

# Drop the identified columns
dataset_processed = dataset.drop(columns=cols_to_drop)

print("Dropped the following columns due to high missing values:")
print(cols_to_drop)
print(f"Shape of dataset after dropping columns: {dataset_processed.shape}")
```

---

### **Step 2: Encode the Target Variable**

**Objective:**
Convert the categorical `Target` column (containing text like 'Smoker') into a numerical format that the model can understand.

**Theory:**
Machine learning algorithms require all input and output variables to be numeric. Encoding is the process of converting categorical labels into numbers. For the target variable, a simple `LabelEncoder` is ideal. It will assign a unique integer to each class (e.g., 'Smoker' -> 1, 'Non-Smoker' -> 0).

**Tools & Syntax:**

*   **Scikit-learn's `LabelEncoder`:** This is the standard tool for encoding a target variable.

```python
from sklearn.preprocessing import LabelEncoder

# Initialize the encoder
le = LabelEncoder()

# Fit the encoder to the Target column and transform it
dataset_processed['Target'] = le.fit_transform(dataset_processed['Target'])

print("
Target column after encoding:")
print(dataset_processed['Target'].value_counts())
# You can see the mapping with: print(le.classes_)
```

---

### **Step 3: Drop Identifier Columns**

**Objective:**
Remove columns that serve only as identifiers and have no predictive value.

**Theory:**
The `Dataset ID` column simply identifies the source of the data rows. It does not describe the characteristics of the samples themselves. Including such columns can confuse the model, as it might incorrectly learn patterns related to the data source rather than the underlying features.

**Tools & Syntax:**

*   **Pandas `.drop()`:** We will use this method again to remove the specified column.

```python
# Drop the 'Dataset ID' column
# Make sure this column exists before trying to drop it
if 'Dataset ID' in dataset_processed.columns:
    dataset_processed = dataset_processed.drop(columns=['Dataset ID'])
    print("
'Dataset ID' column dropped.")
```
---

### **Step 4: Handle Remaining Missing Feature Values**

**Objective:**
Decide on a strategy for the moderate amount of missing data (6-7%) in the remaining feature columns.

**Theory:**
You have two excellent options here.

1.  **Let XGBoost Handle It (Recommended):** XGBoost has a powerful built-in capability to handle missing values (NaNs). When it encounters a missing value during tree construction, it learns a "default path" for that feature—essentially, it learns whether it's better to treat missing values as going down the left or right branch of the tree. This is often more effective than simple imputation.
2.  **Impute with the Mean:** If you prefer to handle missing values explicitly, imputation is the way to go. Since your data is already Z-score normalized, the mean of each column is very close to 0. Filling missing values with the mean (0) is a statistically sound and simple approach in this context.

For this plan, we will proceed with the recommended approach of letting XGBoost handle it, which means **no code is needed for this step**. The remaining `NaN` values in columns like `MQ-3`, `MQ-138`, etc., will be left as they are.

---

### **Step 5: Separate Features (X) and Target (y)**

**Objective:**
Create the final feature matrix `X` and target vector `y` that will be used to train the model.

**Theory:**
This is the final organizational step. The model needs to be given the features (X) and the corresponding labels (y) to learn the relationship between them.

**Tools & Syntax:**
*   We will select the `Target` column as our `y` and all other columns as our `X`.

```python
# Separate features and target
X = dataset_processed.drop(columns='Target')
y = dataset_processed['Target']

print(f"
Final shape of feature matrix X: {X.shape}")
print(f"Final shape of target vector y: {y.shape}")
```

Your data is now preprocessed and ready for splitting into training/testing sets and for model training.
